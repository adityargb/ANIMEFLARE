<div class="dooplay-main-slier">
	<div class="item">
		<span class="rating">5.8</span>
		<div class="image"><img src="https://image.tmdb.org/t/p/original/4lWr2j3ZSEe8qlt3W3ma8TiiMQB.jpg"></div>
		<div class="data">
			<div class="text">
				<h3 class="title">Forgetting Sarah Marshall</h3>
				<p class="subtitle">You lose some, you get some.</p>
				<strong class="year">2020</strong>
			</div>
		</div>
	</div>
</div>
